Sample Java Application V3.6
